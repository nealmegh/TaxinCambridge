<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/Frontend/Profile/paymentSuccess.blade.php */ ?>
<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('Backend.Car.Associate.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="page-title">


            <div class="title_right">

            </div>
        </div>

        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
               <h1>Your Booking has been successfully done. Please check your email for further updates.
                  <br> Call us on +441223 247 247 for any assistance.</h1>
            </div>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('Backend.Car.Associate.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->appendSection(); ?>
<?php echo $__env->make('Frontend.Profile.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>