<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/Backend/Car/index.blade.php */ ?>
<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('Backend.Car.Associate.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="page-title">
            
                
            

            <div class="title_right">
                
                    
                        
                        
                      
                    
                    
                
            </div>
        </div>

        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Basic Model <small>Cars</small></h2>
                        <ul class="nav navbar-right panel_toolbox">
                            
                            
                            
                                
                                
                                    
                                    
                                    
                                    
                                
                            
                            <li><a title="Create a Car Type" href="<?php echo e(route('cars.create')); ?>" class="btn btn-app">
                                    <i class="fa fa-car"></i> <span>Create </span>
                                </a>
                                
                            </li>
                        </ul>

                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        
                            
                        
                        <table id="datatable" class="table table-striped table-bordered">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th>Size</th>
                                <th>Luggage</th>
                                <th>Fair</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                            </thead>


                            <tbody>
                            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($car->name); ?></td>
                                <td><?php echo e($car->size); ?></td>
                                <td><?php echo e($car->luggage); ?></td>
                                <td><?php echo e($car->fair); ?></td>
                                <td><?php echo e($car->status); ?></td>
                                <td>          <a href="<?php echo e(route('cars.show', $car->id)); ?>" data-toggle="modal"  class="btn btn-sm btn-success viewFunction">
                                        <i class="fa fa-eye"></i>
                                    </a> ||
                                    <a href="<?php echo e(route('cars.edit', $car->id)); ?>" data-toggle="modal" class="btn btn-sm btn-warning editFunction" data-row-id="37">
                                        <i class="fa fa-pencil"></i>
                                    </a> ||

                                    <a class="btn btn-danger" onclick="return confirm('Are you sure?')" href="<?php echo e(route('cars.delete', $car->id)); ?>" class="btn btn-sm btn-danger">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('Backend.Car.Associate.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->appendSection(); ?>
<?php echo $__env->make('Backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>