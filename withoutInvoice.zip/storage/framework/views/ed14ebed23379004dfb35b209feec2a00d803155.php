<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/Backend/Booking/payment.blade.php */ ?>
<?php $__env->startSection('css'); ?>
    
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Payment <small>Process</small></h2>

                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                            <form class="form-horizontal form-label-left" novalidate method="POST" action="<?php echo e(route('cashPayment')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($booking->id); ?>">
                                <button style="margin-top: 1px" name="type" value="cash" id="bookingButton" class="btn confirmBtn" type="submit"> <?php echo e('Pay Cash'); ?> </button>
                            </form>
                            <form class="form-horizontal form-label-left" novalidate method="POST" action="<?php echo e(route('paypalPayment')); ?>">
                                <?php echo csrf_field(); ?>
                                <?php if($booking->final_price != null): ?>
                                    <input type="hidden" name="amount" value="<?php echo e($booking->final_price); ?>">
                                <?php else: ?>
                                    <input type="hidden" name="amount" value="<?php echo e($booking->price); ?>">
                                <?php endif; ?>
                                <input type="hidden" name="booking_id" value="<?php echo e($booking->id); ?>">
                                <button style="margin-top: 1px" name="type" value="paypal" id="bookingButton2" class="btn confirmBtn" type="submit"><?php echo e('Pay By Paypal'); ?></button>
                            </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('Backend.Car.Associate.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->appendSection(); ?>
<?php echo $__env->make('Backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>