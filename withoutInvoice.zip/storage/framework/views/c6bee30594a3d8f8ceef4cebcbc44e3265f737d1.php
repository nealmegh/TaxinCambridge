<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/2Frontend/Associate/features.blade.php */ ?>
<section class="container-fluid section-space section-bg-1">
    <div class="container">
        <h2 class="center h2-bottom">Our awesome features </h2>
        <div class="row">
            <div class="col-md-10 column-center no-padding res-width-full">
                <div class="col-md-6 col-sm-6 col-xs-6 common-full features-res-bottom">
                    <div class="features-icon-left">
                        <img src="<?php echo e(asset('images/2Frontend/64x64x5.jpg')); ?>" alt="image" />
                    </div>
                    <div class="features-pad-left features-bottom">
                        <h4 class="left h4-bottom"><a href="#">Cheapest Rate Guranteed</a></h4>
                        <p class="left">Taxi in Cambridge ensures the best rate for your selected route. We are also the cheapest rate airport shuttle service in Cambridge. </p>
                    </div>

                    <div class="features-icon-left">
                        <img src="<?php echo e(asset('images/2Frontend/64x64x6.jpg')); ?>" alt="image" />
                    </div>
                    <div class="features-pad-left features-bottom">
                        <h4 class="left h4-bottom"><a href="#">100% On Time</a></h4>
                        <p class="left">Taxi in Cambridge maintain a highly sofisticated scheduler to maintain 100% on time reproting for best customer satisfaction. </p>
                    </div>
                </div>

                <div class="col-md-6 col-sm-6 col-xs-6 common-full">
                    <div class="features-icon-left">
                        <img src="<?php echo e(asset('images/2Frontend/64x64x7.jpg')); ?>" alt="image" />
                    </div>
                    <div class="features-pad-left features-bottom">
                        <h4 class="left h4-bottom"><a href="#">Secure Payment</a></h4>
                        <p class="left">We value your security concern. Thus we ensure most secured online payment for our valued customers. </p>
                    </div>

                    <div class="features-icon-left">
                        <img src="<?php echo e(asset('images/2Frontend/64x64x8.jpg')); ?>" alt="image" />
                    </div>
                    <div class="features-pad-left features-bottom">
                        <h4 class="left h4-bottom"><a href="#">WIFI Onboard</a></h4>
                        <p class="left">We try to keep our customers always connected online. Ask for our free and complementary wifi service on board. </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>