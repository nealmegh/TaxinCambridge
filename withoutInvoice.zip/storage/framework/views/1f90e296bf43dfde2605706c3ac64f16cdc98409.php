<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/Backend/layout.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('Backend.Associate.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body class="nav-md">
<div class="container body">
    <div class="main_container">
        <div class="col-md-3 left_col">
            <div class="left_col scroll-view">
                <div class="navbar nav_title" style="border: 0;">
                    <a href="/" class="site_title"><i class="fa fa-paw"></i> <span>Taxi In Cambridge</span></a>
                </div>

                <div class="clearfix"></div>

                <!-- menu profile quick info -->
                <div class="profile clearfix">
                    <div class="profile_pic">
                        <img src="<?php echo e(URL::to('/')); ?>/images/user.png" alt="..." class="img-circle profile_img">
                    </div>
                    <div class="profile_info">
                        <span>Welcome,</span>
                        <h2><?php echo e(Auth::user()->name); ?></h2>
                    </div>
                </div>
                <!-- /menu profile quick info -->

                <br />

                <!-- sidebar menu -->
                <?php echo $__env->make('Backend.Sidebar.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- /sidebar menu -->

                <!-- /menu footer buttons -->
                <?php echo $__env->make('Backend.Sidebar.sidebarFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- /menu footer buttons -->
            </div>
        </div>

        <!-- top navigation -->
        <?php echo $__env->make('Backend.Associate.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
            <?php if(Session::has('message')): ?>
                <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('message')); ?></p>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php echo $__env->make('Backend.Associate.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /footer content -->
    </div>
</div>

<!-- jQuery -->
<script src="<?php echo e(asset("js/jquery.min.js")); ?>"></script>
<!-- Bootstrap -->
<script src="<?php echo e(asset("js/bootstrap.min.js")); ?>"></script>
<!-- FastClick -->
<script src="<?php echo e(asset("js/fastclick.js")); ?>"></script>
<!-- NProgress -->
<script src="<?php echo e(asset("js/nprogress.js")); ?>"></script>
<!-- Chart.js -->
<script src="<?php echo e(asset("js/Chart.min.js")); ?>"></script>
<!-- gauge.js -->
<script src="<?php echo e(asset("js/gauge.min.js")); ?>"></script>
<!-- bootstrap-progressbar -->
<script src="<?php echo e(asset("js/bootstrap-progressbar.min.js")); ?>"></script>
<!-- iCheck -->
<script src="<?php echo e(asset("js/icheck.min.js")); ?>"></script>
<!-- Skycons -->
<script src="<?php echo e(asset("js/skycons.js")); ?>"></script>
<!-- Flot -->
<script src="<?php echo e(asset("js/jquery.flot.js")); ?>"></script>
<script src="<?php echo e(asset("js/jquery.flot.pie.js")); ?>"></script>
<script src="<?php echo e(asset("js/jquery.flot.time.js")); ?>"></script>
<script src="<?php echo e(asset("js/jquery.flot.stack.js")); ?>"></script>
<script src="<?php echo e(asset("js/jquery.flot.resize.js")); ?>"></script>
<!-- Flot plugins -->
<script src="<?php echo e(asset("js/jquery.flot.orderBars.js")); ?>"></script>
<script src="<?php echo e(asset("js/jquery.flot.spline.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/curvedLines.js")); ?>"></script>
<!-- DateJS -->
<script src="<?php echo e(asset("js/date.js")); ?>"></script>
<!-- JQVMap -->
<script src="<?php echo e(asset("js/jquery.vmap.js")); ?>"></script>
<script src="<?php echo e(asset("js/jquery.vmap.world.js")); ?>"></script>
<script src="<?php echo e(asset("js/jquery.vmap.sampledata.js")); ?>"></script>
<!-- bootstrap-daterangepicker -->
<script src="<?php echo e(asset("js/moment.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/daterangepicker.js")); ?>"></script>

<!-- Custom Theme Scripts -->
<script src="<?php echo e(asset("js/custom.min.js")); ?>" ></script>

<?php echo $__env->yieldContent('js'); ?>

</body>
</html>



