<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/Backend/Car/show.blade.php */ ?>
<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('Backend.Car.Associate.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        th{
            text-align: center !important;
        }
    </style>
    <div class="">
        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Car Type <small>Show</small></h2>

                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">

                        <table class="table table-striped text-center table-bordered">
                            <thead>
                            <tr>
                                <th>Attributes</th>
                                <th>Values</th>

                            </tr>
                            </thead>


                            <tbody>

                                <tr>
                                    <td>Name</td>
                                    <td><?php echo e($car->name); ?></td>

                                </tr>
                                <tr>
                                    <td>Size</td>
                                    <td><?php echo e($car->size); ?></td>

                                </tr>
                                <tr>
                                    <td>Luggage Capacity</td>
                                    <td><?php echo e($car->luggage); ?></td>

                                </tr>
                                <tr>
                                    <td>Fair</td>
                                    <td><?php echo e($car->fair); ?></td>

                                </tr>
                                <tr>
                                    <td>Description</td>
                                    <td><?php echo e($car->description); ?></td>

                                </tr>
                                <tr>
                                    <td>Status</td>
                                    <td><?php if($car->status == 0): ?><?php echo e('Inactive'); ?><?php else: ?><?php echo e('Active'); ?><?php endif; ?></td>

                                </tr>


                            </tbody>
                        </table>

                    </div></div></div></div></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('Backend.Car.Associate.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->appendSection(); ?>
<?php echo $__env->make('Backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>