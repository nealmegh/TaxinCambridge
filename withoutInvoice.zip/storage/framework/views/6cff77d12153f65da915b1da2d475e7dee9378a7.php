<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/Backend/Location/index.blade.php */ ?>
<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('Backend.Car.Associate.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="page-title">
            
                
            

            <div class="title_right">
                
                    
                        
                        
                      
                    
                    
                
            </div>
        </div>

        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Basic Model <small>Locations</small></h2>
                        <ul class="nav navbar-right panel_toolbox">
                            
                            
                            
                                
                                
                                    
                                    
                                    
                                    
                                
                            
                            <li><a title="Create a Airport" href="<?php echo e(route('location.create')); ?>" class="btn btn-app">
                                     <i class="fa fa-plane"></i> <span>Create </span>
                                </a>
                                
                            </li>
                        </ul>

                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        
                            
                        
                        <table id="datatable" class="table table-striped table-bordered">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th>Display Name</th>
                                <th>Actions</th>
                            </tr>
                            </thead>


                            <tbody>
                            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($location->name); ?></td>
                                <td><?php echo e($location->display_name); ?></td>

                                <td>
                                    
                                        
                                    
                                    <a href="<?php echo e(route('location.edit', $location->id)); ?>" data-toggle="modal" class="btn btn-sm btn-warning editFunction" data-row-id="37">
                                        <i class="fa fa-pencil"></i>
                                    </a>
                                    

                                    ||

                                    <a class="btn btn-danger" onclick="return confirm('Are you sure?')" href="<?php echo e(route('location.delete', $location->id)); ?>" class="btn btn-sm btn-danger">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('Backend.Car.Associate.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->appendSection(); ?>
<?php echo $__env->make('Backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>