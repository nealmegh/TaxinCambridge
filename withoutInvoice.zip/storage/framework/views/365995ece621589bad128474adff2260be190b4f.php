<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/Backend/Car/Associate/css.blade.php */ ?>

<link href=" <?php echo e(asset("css/bootstrap-progressbar-3.3.4.min.css")); ?> " rel="stylesheet">

<link href="<?php echo e(asset("css/dataTables.bootstrap.min.css")); ?>" rel="stylesheet">
<link href="<?php echo e(asset("css/buttons.bootstrap.min.css")); ?>" rel="stylesheet">
<link href="<?php echo e(asset("css/fixedHeader.bootstrap.min.css")); ?>" rel="stylesheet">
<link href="<?php echo e(asset("css/responsive.bootstrap.min.css")); ?>" rel="stylesheet">
<link href="<?php echo e(asset("css/scroller.bootstrap.min.css")); ?>" rel="stylesheet">
<link href="<?php echo e(asset("js/bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.css")); ?>" rel="stylesheet">
    