<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/Backend/Location/fairs.blade.php */ ?>
<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('Backend.Car.Associate.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="page-title">
            
            
            

            <div class="title_right">
                
                
                
                
                
                
                
                
            </div>
        </div>

        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Basic Model <small>Locations</small></h2>
                        <ul class="nav navbar-right panel_toolbox">
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            <li><a title="Create a Airport" href="<?php echo e(route('location.create')); ?>" class="btn btn-app">
                                    <i class="fa fa-plane"></i> <span>Create </span>
                                </a>
                                
                            </li>
                        </ul>

                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        
                        
                        
                        <table id="datatable" class="table table-striped table-bordered">
                            <thead>
                            <tr>
                                <th>Location</th>
                                <th>Airport</th>
                                <th>Fair</th>
                            </tr>
                            </thead>


                            <tbody>
                            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $location->airports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($location->name); ?></td>
                                    <td><?php echo e($airport->name); ?></td>

                                    <td>
                                        
                                        
                                        
                                        
                                            
                                        
                                        

                                        
                                        
                                        
                                        <?php echo e($airport->pivot->price); ?>

                                    </td>
                                </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('Backend.Car.Associate.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->appendSection(); ?>
<?php echo $__env->make('Backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>