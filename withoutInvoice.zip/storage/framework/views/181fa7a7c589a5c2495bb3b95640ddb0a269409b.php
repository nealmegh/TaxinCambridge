<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/Backend/Associate/footer.blade.php */ ?>
<footer>
    <div class="pull-right">
        Taxi in Cambridge made by <a href="https://bluwebz.com">Bluwebz</a>
    </div>
    <div class="clearfix"></div>
</footer>