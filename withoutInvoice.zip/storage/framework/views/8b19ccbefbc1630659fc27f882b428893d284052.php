<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/Frontend/Associate/footer.blade.php */ ?>
<footer class="footer-area section-gap">
    <div class="container">
        <div class="footer-1">
            <p>London Taxi and Privet Hire (LTPH) licence number 06294/02/03.</p>
            <p>@ 2009-2019 Ivory Enterprise Ltd.</p>
        </div>

        <div class="row">
            <div class="col-md-4">
                <h2 style="padding-top:60px;"><span style="font-size:28px;">Dial</span> <span style="font-size:40px; color: blue; font-weight: 600">0207 005 0557</span></h2>
            </div>
            <div class="col-md-4 offset-md-4">
                <img src="<?php echo e(asset("images/untitled-3.png")); ?>">
            </div>

        </div>
    </div>

    
</footer>