<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/Email/contactForm.blade.php */ ?>
<?php echo e($data['from']); ?>

<?php echo e($data['message']); ?>


