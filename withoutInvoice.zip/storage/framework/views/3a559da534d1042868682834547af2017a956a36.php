<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/Frontend/Associate/header.blade.php */ ?>
<header class="header_area">
    <div class="main_menu">
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container box_1620">
                <!-- Brand and toggle get grouped for better mobile display -->
                <a class="navbar-brand logo_h" href="/"><img src="<?php echo e(asset("images/logo.png")); ?>" alt=""></a>
                
                    
                    
                    
                
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse offset" id="navbarSupportedContent">
                    
                        
                        
                        
                        
                        
                        
                    

                    <ul class="navbar-right">
                        <?php if(Auth::user()): ?>
                            <li class="nav-item active"><a class="nav-link" href="<?php echo e(route('userProfile')); ?>"> My Account</a></li>
                            <li><form id="logout-form" method="post" action="<?php echo e(route('logout')); ?>">
                                    <?php echo csrf_field(); ?>

                                    <input type="submit" value="logout">
                                    
                                    
                                    
                                </form>
                            </li>
                        <?php else: ?>
                            <li class="nav-item"><a class="nav-link" href="/login">Login</a></li>
                            <li class="nav-item"><a class="nav-link" href="/register">Register</a>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a href="#" style="color:white;"> <span class="fa-stack"><i class="fa fa-circle fa-stack-2x" style="color:blue;"></i><i class='fa fa-phone fa-stack-1x' style=''></i></span>(01223) 247 247</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
</header>