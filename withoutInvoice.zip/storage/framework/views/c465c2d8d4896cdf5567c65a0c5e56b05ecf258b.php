<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/Frontend/clientMain.blade.php */ ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Cheapest Airport Transfer in Cambridge</title>
    <!--meta info--><meta name="author" content="onlinecuisine.co.uk"><meta name="keywords" content="taxi in cambridge, 247 airport transfer, cheapest airport transfer in cambridge, 247 airport taxi near me, cambridge to heathrow taxi, heathrow transfer"><meta name="description" content="Taxi in Cambridge is the most reliable and cheapest airport transfer service in Cambridge.  Book us online for best fare to any airport transfer taxi service from Cambridge."><!-- Mobile Specific Metas
	<!-- TrustBox script --> <script type="text/javascript" src="//widget.trustpilot.com/bootstrap/v5/tp.widget.bootstrap.min.js" async></script> <!-- End TrustBox script -->
    <!-- FAVICON LINK -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png">
    <!-- BOOTSTRAP -->
    <link rel="stylesheet" type="text/css" href="css/vendor/bootstrap.min.css">

    <!-- FONT AWESOME LINK -->
    <link rel="stylesheet" type="text/css" href="css/vendor/font-awesome/css/font-awesome.min.css">

    <!-- CAROUSEL STYLE LINK  -->
    <link rel="stylesheet" type="text/css" href="css/vendor/owl-carousel/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="css/vendor/owl-carousel/owl.theme.css">
    <link rel="stylesheet" type="text/css" href="css/vendor/owl-carousel/carousel.css">


    <!-- CUSTOM CSS -->
    <link rel="stylesheet" type="text/css" href="css/custom/style_green.css">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body data-spy="scroll" data-target=".navbar-fixed-top" data-offset="75">

<!--================================= NAVIGATION START =============================================-->
<nav class="navbar navbar-default navbar-fixed-top menu-bg" id="top-nav">
    <div class="container">
        <div class="navigation-tb">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div>
                    <a href="#"> <img src="images/logo.jpg" alt="logo" />
                    </a>
                </div>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right no-margin" id="menu-list">
                    <li class="menu-fs menu-underline"><a href="#home" class="pagescroll">home</a>
                    </li>
                    <li class="menu-fs menu-underline"><a href="#services" class="pagescroll">services</a>
                    </li>
                    <li class="menu-fs menu-underline"><a href="#price" class="pagescroll"> price </a>
                    </li>
                    <!--    <li class="menu-fs menu-underline"><a href="#gallery" class="pagescroll"> gallery</a>
                        </li>  -->
                    <li class="menu-fs menu-underline"><a href="#contact" class="pagescroll"> contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>
<!--================================= NAVIGATION END =============================================-->

<!--================================= HEADER-1 START =============================================-->
<div class="container-fluid header-bgimage bgimage-property header-section-space" id="home">
    <div class="container">
        <div class="col-md-12 column-center no-padding white-text">
            <h1 class="center header-head1-bottom">safe &amp; trusted service</h1>
            <h3 class="center">We Pick Up &amp; Drop You On Time by Best Tariff </h3>
            <div class="center btn-top">
                <a href="#">
                    <div class="header-btn">Book Now</div>
                </a>
            </div>
        </div>
    </div>
</div>
<!--================================= HEADER-1 END =============================================-->
<!-- TrustBox widget - Micro Review Count --> <div class="trustpilot-widget" data-locale="en-GB" data-template-id="5419b6a8b0d04a076446a9ad" data-businessunit-id="5ccdf0bc4786990001508f46" data-style-height="94px" data-style-width="100%" data-theme="light"> <a href="https://uk.trustpilot.com/review/taxiincambridge.co.uk" target="_blank" rel="noopener">Trustpilot</a> </div> <!-- End TrustBox widget -->

<!--================================= MAINTENANCE START =============================================-->
<section class="container-fluid section-space section-bg-1">
    <div class="container">
        <h2 class="center h2-bottom">Our Services for You</h2>
        <div class="row">
            <!--=============== COLUMN-1 ==================-->
            <div class="col-md-4 col-sm-4 common-res-bottom-1">
                <div class="left image-bottom">
                    <img src="images/750x500x1.jpg" alt="image" class="img-responsive image-center" />
                </div>
                <h4 class="center h4-bottom"><a href="#">Airport Transfer</a></h4>
                <p class="center">Taxi in Cambridge provides most reliable airport transfer service from and to all UK airports. We have a range of vehicles and trusted drivers for your pleasent journey. </p>
            </div>

            <!--=============== COLUMN-2 ==================-->
            <div class="col-md-4 col-sm-4 common-res-bottom-1">
                <div class="left image-bottom">
                    <img src="images/750x500x2.jpg" alt="image" class="img-responsive image-center" />
                </div>
                <h4 class="center h4-bottom"><a href="#">Long Distance Trip</a></h4>
                <p class="center">We also offer best tarrif for long distance trip nation wide from Cambridge. Our comfortable and luxury cars definately give you best experince in your long journey. </p>
            </div>

            <!--=============== COLUMN-3 ==================-->
            <div class="col-md-4 col-sm-4">
                <div class="left image-bottom">
                    <img src="images/750x500x3.jpg" alt="image" class="img-responsive image-center" />
                </div>
                <h4 class="center h4-bottom"><a href="#">Hire us for Occassion</a></h4>
                <p class="center">No matter it is a west-end party or just a birthday at granny's home. Book Taxi in Cambridge for any of your event drop-off. We will ensure your ontime arrival at desired location.</p>
            </div>
        </div>
    </div>
</section>
<!--================================= MAINTENANCE END =============================================-->

<!--================================= OUR AWESOME SERVICES START =============================================-->
<section class="container-fluid section-space section-bg-2" id="services">
    <div class="container">
        <h2 class="center h2-bottom">our awesome services </h2>
        <div class="row">
            <!--=============== COLUMN-1 ==================-->
            <div class="col-md-3 col-sm-6 col-xs-6 services-res-bottom common-full-1">
                <div class="services-bg">
                    <div class="center image-bottom">
                        <img src="images/64x64x1.jpg" alt="image" />
                    </div>
                    <h4 class="center h4-bottom"><a href="#">247 Support</a></h4>
                    <p class="center">We provide support for our customers round the clock so  that our loyal customer always have a safe and uninterruptable journey.  </p>
                </div>
            </div>

            <!--=============== COLUMN-2 ==================-->
            <div class="col-md-3 col-sm-6 col-xs-6 services-res-bottom common-full-1">
                <div class="services-bg">
                    <div class="center image-bottom">
                        <img src="images/64x64x2.jpg" alt="image" />
                    </div>
                    <h4 class="center h4-bottom"><a href="#">Best Reviews</a></h4>
                    <p class="center">Our service reflects on our customers reviews. We are most truested and reliable airport transfer service in cambridge. </p>
                </div>
            </div>

            <!--=============== COLUMN-3 ==================-->
            <div class="col-md-3 col-sm-6 col-xs-6 common-full-1 services-res-bottom-1">
                <div class="services-bg">
                    <div class="center image-bottom">
                        <img src="images/64x64x3.jpg" alt="image" />
                    </div>
                    <h4 class="center h4-bottom"><a href="#">Vehicle Choice </a></h4>
                    <p class="center">Taxi in Cambridge provides service with range of modern and prestigious fleet of vehicles from Saloon to large 7 seaters.  </p>
                </div>
            </div>

            <!--=============== COLUMN-4 ==================-->
            <div class="col-md-3 col-sm-6 col-xs-6 common-full-1">
                <div class="services-bg">
                    <div class="center image-bottom">
                        <img src="images/64x64x4.jpg" alt="image" />
                    </div>
                    <h4 class="center h4-bottom"><a href="#">Live Support</a></h4>
                    <p class="center">Our customers book our service from around the world. For their peace of mind we dont sleep. If they need us at anytime. </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================================= OUR AWESOME SERVICES END =============================================-->

<!--================================= OUR AWESOME FEATURES START =============================================-->
<section class="container-fluid section-space section-bg-1">
    <div class="container">
        <h2 class="center h2-bottom">Our awesome features </h2>
        <div class="row">
            <div class="col-md-10 column-center no-padding res-width-full">
                <div class="col-md-6 col-sm-6 col-xs-6 common-full features-res-bottom">
                    <div class="features-icon-left">
                        <img src="images/64x64x5.jpg" alt="image" />
                    </div>
                    <div class="features-pad-left features-bottom">
                        <h4 class="left h4-bottom"><a href="#">Cheapest Rate Guranteed</a></h4>
                        <p class="left">Taxi in Cambridge ensures the best rate for your selected route. We are also the cheapest rate airport shuttle service in Cambridge. </p>
                    </div>

                    <div class="features-icon-left">
                        <img src="images/64x64x6.jpg" alt="image" />
                    </div>
                    <div class="features-pad-left features-bottom">
                        <h4 class="left h4-bottom"><a href="#">100% On Time</a></h4>
                        <p class="left">Taxi in Cambridge maintain a highly sofisticated scheduler to maintain 100% on time reproting for best customer satisfaction. </p>
                    </div>
                </div>

                <div class="col-md-6 col-sm-6 col-xs-6 common-full">
                    <div class="features-icon-left">
                        <img src="images/64x64x7.jpg" alt="image" />
                    </div>
                    <div class="features-pad-left features-bottom">
                        <h4 class="left h4-bottom"><a href="#">Secure Payment</a></h4>
                        <p class="left">We value your security concern. Thus we ensure most secured online payment for our valued customers. </p>
                    </div>

                    <div class="features-icon-left">
                        <img src="images/64x64x8.jpg" alt="image" />
                    </div>
                    <div class="features-pad-left features-bottom">
                        <h4 class="left h4-bottom"><a href="#">WIFI Onboard</a></h4>
                        <p class="left">We try to keep our customers always connected online. Ask for our free and complementary wifi service on board. </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================================= OUR AWESOME FEATURES END =============================================-->

<!--================================= 	LUXURY CARS START =============================================-->
<!--
    <section class="container-fluid section-space section-bg-2">
        <div class="container">
			<h2 class="center h2-bottom">pick-up &amp; drop</h2>
            <div class="row">
                <div class="col-md-12 column-center no-padding">
                    <!--=============== COLUMN-1 ==================-->
<!--
					<div class="col-md-4 col-sm-6 common-res-bottom-1">
						<div class="luxury-bgimage bgimage-property">
							<div class="luxury-center">
								<div class="distab">
									<div class="left distab-cell-middle">
										<img src="images/80x80x1.png" alt="icon" />
									</div>
									<div class="left distab-cell-middle luxury-left-pad">
										<h4 class="left"><a href="#">luxury cars</a></h4>
									</div>
								</div>

								<div class="left luxury-line-pad">
									<img src="images/luxury_line.png" alt="icon" />
								</div>

								<div class="distab">
									<div class="left distab-cell-middle">
										<img src="images/80x80x2.png" alt="icon" />
									</div>
									<div class="left distab-cell-middle luxury-left-pad">
										<h4 class="left"><a href="#">fast &amp; safe</a></h4>
									</div>
								</div>

								<div class="left luxury-line-pad">
									<img src="images/luxury_line.png" alt="icon" />
								</div>

								<div class="distab">
									<div class="left distab-cell-middle">
										<img src="images/80x80x3.png" alt="icon" />
									</div>
									<div class="left distab-cell-middle luxury-left-pad">
										<h4 class="left"><a href="#">best tariff</a></h4>
									</div>
								</div>
							</div>
						</div>
					</div>

                    <!--=============== COLUMN-2 ==================-->
<!--
					 <div class="col-md-8 col-sm-6">
                        <div class="luxury-text-top">
                            <div class="left image-bottom">
                                <img src="images/750x340.jpg" alt="image" class="img-responsive image-center" />
                            </div>
                            <h4 class="left h4-bottom"><a href="#">on time pick-up &amp; drop by experienced cab drivers</a></h4>
                            <p class="left">Donec varius sodales orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean a arcu ullamcorper eros viverra suscipit. Donec varius </p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!--================================= LUXURY CARS END =============================================-->

<!--================================= WHY CHOOSE US START =============================================-->
<section class="container-fluid section-space section-bg-1">
    <div class="container">
        <h2 class="center h2-bottom">why choose us </h2>
        <div class="row">
            <!--=============== COLUMN-1 ==================-->
            <div class="col-md-3 col-sm-6 col-xs-6 why-res-bottom common-res-bottom-1 common-full-1">
                <h4 class="center h4-bottom"><a href="#">Fast Booking</a></h4>
                <p class="center">Our online booking tool wont take more than 5 minutes for booking. </p>
            </div>

            <!--=============== COLUMN-2 ==================-->
            <div class="col-md-3 col-sm-6 col-xs-6 why-res-bottom common-res-bottom-1 common-full-1">
                <h4 class="center h4-bottom"><a href="#">Experienced Drivers</a></h4>
                <p class="center">Taxi in Cambridge ensures all fo our drivers have proper experience and qualifications. </p>
            </div>

            <!--=============== COLUMN-3 ==================-->
            <div class="col-md-3 col-sm-6 col-xs-6 common-full-1 why-res-bottom-1">
                <h4 class="center h4-bottom"><a href="#">On Time Arrival</a></h4>
                <p class="center">We have a very strong history of timely arrival. This achievement ensured us customer reliability.  </p>
            </div>

            <!--=============== COLUMN-4 ==================-->
            <div class="col-md-3 col-sm-6 col-xs-6 common-full-1">
                <h4 class="center h4-bottom"><a href="#">Phone & Online Support</a></h4>
                <p class="center">Have a question to ask? Just dial our number 247 in 365 days. </p>
            </div>
        </div>
    </div>
</section>
<!--================================= WHY CHOOSE US END =============================================-->

<!--================================= TAXI APP START =============================================-->
<!--
    <section class="container-fluid section-space section-bg-2">
        <div class="container">
            <div class="row">
                <!--=============== COLUMN-1 ==================-->
<!--
                <div class="col-md-4 col-sm-4 common-res-bottom-1">
                    <div class="app-bg">
                        <div class="distab app-heading-bottom">
                            <div class="left distab-cell-middle">
                                <img src="images/32x32x1.png" alt="icon" />
                            </div>
                            <div class="left distab-cell-middle app-left-pad">
                                <h4 class="center"><a href="#">taxi app</a></h4>
                            </div>
                        </div>
                        <p class="left">Donec varius sodales orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos</p>
                    </div>
                </div>

                <!--=============== COLUMN-2 ==================-->
<!--
                <div class="col-md-4 col-sm-4 common-res-bottom-1">
                    <div class="app-bg">
                        <div class="distab app-heading-bottom">
                            <div class="left distab-cell-middle">
                                <img src="images/32x32x2.png" alt="icon" />
                            </div>
                            <div class="left distab-cell-middle app-left-pad">
                                <h4 class="center"><a href="#">car rental</a></h4>
                            </div>
                        </div>
                        <p class="left">Donec varius sodales orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos</p>
                    </div>
                </div>

                <!--=============== COLUMN-3 ==================-->
<!--
                <div class="col-md-4 col-sm-4">
                    <div class="app-bg">
                        <div class="distab app-heading-bottom">
                            <div class="left distab-cell-middle">
                                <img src="images/32x32x3.png" alt="icon" />
                            </div>
                            <div class="left distab-cell-middle app-left-pad">
                                <h4 class="center"><a href="#">live support</a></h4>
                            </div>
                        </div>
                        <p class="left">Donec varius sodales orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--================================= TAXI APP END =============================================-->

<!--================================= COUNTER START =============================================-->
<!--
    <section class="container-fluid counter-bgimage bgimage-property counter-section-space white-text">
        <div class="container">
            <div class="row">
                <!--=============== COLUMN-1 ==================-->
<!--
               <div class="col-md-3 col-sm-3 col-xs-3 common-full counter-res-bottom">
                   <div class="center">
                       <img src="images/64x64x10.png" alt="icon" />
                   </div>
                   <p class="center counter-num count">1201 </p>
                   <h4 class="center">packages</h4>
               </div>

               <!--=============== COLUMN-2 ==================-->
<!--
                <div class="col-md-3 col-sm-3 col-xs-3 common-full counter-res-bottom">
					<div class="center">
                        <img src="images/64x64x11.png" alt="icon" />
                    </div>
                    <p class="center counter-num count">543 </p>
                    <h4 class="center">awards</h4>
                </div>

                <!--=============== COLUMN-3 ==================-->
<!--
               <div class="col-md-3 col-sm-3 col-xs-3 common-full counter-res-bottom">
                   <div class="center">
                       <img src="images/64x64x12.png" alt="icon" />
                   </div>
                   <p class="center counter-num count">343 </p>
                   <h4 class="center">clients</h4>
               </div>

                 <!--=============== COLUMN-4 ==================-->
<!--
                <div class="col-md-3 col-sm-3 col-xs-3 common-full">
					<div class="center">
                        <img src="images/64x64x13.png" alt="icon" />
                    </div>
                    <p class="center counter-num count">2010 </p>
                    <h4 class="center">LIKES</h4>
                </div>
            </div>
        </div>
    </section>
    <!--================================= COUNTER END =============================================-->


<!--================================= AVAILABLE CAR TYPES START =============================================-->
<section class="container-fluid section-space section-bg-1">
    <div class="container">
        <h2 class="center h2-bottom">available car types</h2>
        <!--=============== ROW-1 ==================-->
        <div class="row types-row-bottom">
            <div class="col-md-10 column-center no-padding res-width-full">
                <div class="col-md-6 res-image-bottom res-image-bottom-1">
                    <div class="left">
                        <img src="images/750x350x1.jpg" alt="image" class="img-responsive image-center" />
                    </div>
                </div>

                <div class="col-md-6">
                    <h4 class="left h4-bottom">Saloon car</h4>
                    <p class="left">We have range of saloon cars in our fleet. All of our saloon cars allow 4 passengers 2 luggages and 2 carry-ons. If you need more information about our car capacity, do not hesitate to contact us. </p>

                    <div class="left btn-top-1">
                        <a href="#">
                            <div class="btn-1">book now</div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!--=============== ROW-2 ==================-->
        <div class="row types-row-bottom">
            <div class="col-md-10 column-center no-padding res-width-full">
                <div class="col-md-6 res-image-bottom res-image-bottom-1">
                    <div class="left">
                        <img src="images/750x350x2.jpg" alt="image" class="img-responsive image-center" />
                    </div>
                </div>

                <div class="col-md-6">
                    <h4 class="left h4-bottom">Estate car</h4>
                    <p class="left">We have range of Executive cars in our fleet. All of our Executive cars allow 4 passengers 2 luggages and 3 carry-ons. If you need more information about our car capacity, do not hesitate to contact us. </p>

                    <div class="left btn-top-1">
                        <a href="#">
                            <div class="btn-1">book now</div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!--=============== ROW-3 ==================-->
        <div class="row types-row-bottom">
            <div class="col-md-10 column-center no-padding res-width-full">
                <div class="col-md-6 res-image-bottom res-image-bottom-1">
                    <div class="left">
                        <img src="images/750x350x3.jpg" alt="image" class="img-responsive image-center" />
                    </div>
                </div>

                <div class="col-md-6">
                    <h4 class="left h4-bottom">Executive car</h4>
                    <p class="left">We have range of 7 Seaters in our fleet. All of our saloon cars allow 7 passengers 4 luggages and 3 carry-ons. If you need more information about our car capacity, do not hesitate to contact us.</p>

                    <div class="left btn-top-1">
                        <a href="#">
                            <div class="btn-1">book now</div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!--=============== ROW-4 ==================-->
        <div class="row types-row-bottom">
            <div class="col-md-10 column-center no-padding res-width-full">
                <div class="col-md-6 res-image-bottom res-image-bottom-1">
                    <div class="left">
                        <img src="images/750x350x4.jpg" alt="image" class="img-responsive image-center" />
                    </div>
                </div>

                <div class="col-md-6">
                    <h4 class="left h4-bottom">Large 8 Seaters</h4>
                    <p class="left">We have range of 7 Seaters in our fleet. All of our saloon cars allow 7 passengers 4 luggages and 3 carry-ons. If you need more information about our car capacity, do not hesitate to contact us.</p>

                    <div class="left btn-top-1">
                        <a href="#">
                            <div class="btn-1">book now</div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================================= AVAILABLE CAR TYPES END =============================================-->


<!--================================= BEST PRICING PACKAGES START =============================================-->
<section class="container-fluid section-space section-bg-2" id="price">
    <div class="container">
        <h2 class="center h2-bottom">Our Top Destinations</h2>
        <div class="row">
            <!--=============== COLUMN-1 ==================-->
            <div class="col-md-4 col-sm-4 price-fixed price-res-bottom">
                <div class="packages-bg">
                    <h4 class="center">Stanstead Airport</h4>
                    <p class="center pricing-tag ls">From £50 oneway</p>
                    <div class="price-list-bottom">
                        <p class="center ls">Book online or by phone</p>
                        <p class="center ls">24 hours drop off service</p>
                        <p class="center ls">Meet & Greet available</p>

                    </div>
                    <div class="center btn-top-1">
                        <a href="#">
                            <div class="btn-1">book now</div>
                        </a>
                    </div>
                </div>
            </div>

            <!--=============== COLUMN-2 ==================-->
            <div class="col-md-4 col-sm-4 price-fixed price-res-bottom">
                <div class="packages-bg">
                    <h4 class="center">Heathrow Airport</h4>
                    <p class="center pricing-tag ls">From £120 Oneway</p>
                    <div class="price-list-bottom">
                        <p class="center ls">Book online or by phone</p>
                        <p class="center ls">24 hours drop off service</p>
                        <p class="center ls">Meet & Greet available</p>

                    </div>
                    <div class="center btn-top-1">
                        <a href="#">
                            <div class="btn-1">book now</div>
                        </a>
                    </div>
                </div>
            </div>

            <!--=============== COLUMN-3 ==================-->
            <div class="col-md-4 col-sm-4 price-fixed price-res-bottom">
                <div class="packages-bg">
                    <h4 class="center">London City</h4>
                    <p class="center pricing-tag ls">From £120 Oneway</p>
                    <div class="price-list-bottom">
                        <p class="center ls">Book online or by phone</p>
                        <p class="center ls">24 hours drop off service</p>
                        <p class="center ls">Meet & Greet available</p>

                    </div>
                    <div class="center btn-top-1">
                        <a href="#">
                            <div class="btn-1">book now</div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================================= BEST PRICING PACKAGES END =============================================-->

<!--================================= DOOR SERVICE START =============================================-->
<!--
   <section class="container-fluid section-space section-bg-1">
       <div class="container">
        <h2 class="center h2-bottom">our powerful services</h2>
           <div class="row">
               <div class="col-md-10 column-center no-padding res-width-full">

                   <div class="col-md-6 col-sm-6 common-res-bottom-1">
                       <div class="luxury-bg-dark-bgimage bgimage-property white-text">
                           <div class="luxury-center">
                               <div class="distab">
                                   <div class="left distab-cell-middle">
                                       <img src="images/80x80x4.png" alt="icon" />
                                   </div>
                                   <div class="left distab-cell-middle luxury-left-pad">
                                       <h4 class="left"><a href="#">	door service</a></h4>
                                   </div>
                               </div>

                               <div class="left luxury-line-pad">
                                   <img src="images/door_uline.png" alt="icon" />
                               </div>

                               <div class="distab">
                                   <div class="left distab-cell-middle">
                                       <img src="images/80x80x5.png" alt="icon" />
                                   </div>
                                   <div class="left distab-cell-middle luxury-left-pad">
                                       <h4 class="left"><a href="#">airport service</a></h4>
                                   </div>
                               </div>

                               <div class="left luxury-line-pad">
                                   <img src="images/door_uline.png" alt="icon" />
                               </div>

                               <div class="distab">
                                   <div class="left distab-cell-middle">
                                       <img src="images/80x80x6.png" alt="icon" />
                                   </div>
                                   <div class="left distab-cell-middle luxury-left-pad">
                                       <h4 class="left"><a href="#">night service</a></h4>
                                   </div>
                               </div>

                               <div class="left luxury-line-pad">
                                   <img src="images/door_uline.png" alt="icon" />
                               </div>

                               <div class="distab">
                                   <div class="left distab-cell-middle">
                                       <img src="images/80x80x7.png" alt="icon" />
                                   </div>
                                   <div class="left distab-cell-middle luxury-left-pad">
                                       <h4 class="left"><a href="#">hotel transport</a></h4>
                                   </div>
                               </div>
                           </div>
                       </div>
                   </div>

                    <div class="col-md-6 col-sm-6">
                       <div class="left image-bottom">
                           <img src="images/750x740.jpg" alt="image" class="img-responsive image-center" />
                       </div>
                        <p class="left">Donec varius sodales orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean a arcu ullamcorper eros viverra suscipit. Donec varius sodales orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean a arcu ullamcorper.</p>
                   </div>
               </div>

           </div>
       </div>
   </section>
   <!--================================= DOOR SERVICE END =============================================-->

<!--================================= TAXI AVAILABLE 24/7 SERVICE  START =============================================-->

<div class="container-fluid available-bgimage bgimage-property available-section-space">
    <div class="container">
        <div class="col-md-12 column-center no-padding white-text">
            <h2 class="center bgimage-head-bottom">taxi available all days</h2>
            <div class="col-md-8 column-center no-padding">
                <p class="center ls">Donec varius sodales orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean a arcu ullamcorper eros viverra suscipit</p>
            </div>
            <div class="center btn-top">
                <a href="#">
                    <div class="btn-1 btn-ant">book now</div>
                </a>
            </div>
        </div>
    </div>

</div>
<!--================================= TAXI AVAILABLE 24/7 SERVICE  END =============================================-->

<!--================================= MOBILE APP START =============================================-->
<!--
    <div class="container-fluid section-space section-bg-2">
        <div class="container">
            <div class="row">
                <div class="col-md-10 column-center no-padding">
                    <div class="col-md-6 col-sm-6">
                        <div class="left">
                            <img src="images/500x660.png" alt="image" class="img-responsive" />
                        </div>
                    </div>

                    <div class="col-md-6 col-sm-6">
                        <div class="app-heading-top">
							<h3 class="left h3-bottom">fast booking taxi App</h3>
							 <p class="left">Donec varius sodales orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean a arcu ullamcorper eros viverra suscipit</p>
							<!--=============== LIST START ==================-->
<!--
							<div class="app-list-bottom app-list-top">
								<div class="distab">
									<div class="left distab-cell-middle">
										<img src="images/24x24x1.png" alt="icon" />
									</div>
									<div class="left distab-cell-middle app-list-left">
										<p class="left app-list ls">EASY</p>
									</div>
								</div>
							</div>

							<div class="app-list-bottom">
								<div class="distab">
									<div class="left distab-cell-middle">
										<img src="images/24x24x2.png" alt="icon" />
									</div>
									<div class="left distab-cell-middle app-list-left">
										<p class="left app-list ls">SIMPLE</p>
									</div>
								</div>
							</div>

							<div class="app-list-bottom">
								<div class="distab">
									<div class="left distab-cell-middle">
										<img src="images/24x24x3.png" alt="icon" />
									</div>
									<div class="left distab-cell-middle app-list-left">
										<p class="left app-list ls">MODERN</p>
									</div>
								</div>
							</div>

							<div>
								<div class="distab">
									<div class="left distab-cell-middle">
										<img src="images/24x24x4.png" alt="icon" />
									</div>
									<div class="left distab-cell-middle app-list-left">
										<p class="left app-list ls">RESPONSIVE</p>
									</div>
								</div>
							</div>
							<!--=============== LIST END ==================-->
<!--
							<div class="app-top distab">
								<div class="distab-cell-middle app-right">
									<a href="#"> <img src="images/app.png" alt="image" class="img-responsive" />
									</a>
								</div>

								<div class="distab-cell-middle">
									<a href="#"> <img src="images/play.png" alt="image" class="img-responsive" />
									</a>
								</div>
							</div>
						</div>

                    </div>

                </div>

            </div>
        </div>
    </div>
    <!--================================= MOBILE APP END =============================================-->

<!--================================= OUR BEST TARIFF PLANS START =============================================-->
<section class="container-fluid section-space section-bg-1">
    <div class="container">
        <h2 class="center h2-bottom">our best tariffs</h2>
        <div class="row">
            <div class="col-md-8 column-center">
                <!--=============== ROW-1 ==================-->
                <div class="distab plans-radius plans-bg-2">
                    <h4 class="center plans-fs distab-cell-middle plans-br plans-pad"><a href="#">London City Drop-off</a>
                    </h4>

                    <p class="center plans-fs plans-price-fs ls distab-cell-middle plans-pad">£70 </p>
                </div>

                <!--=============== ROW-2 ==================-->
                <div class="distab plans-bg-1">
                    <h4 class="center plans-fs distab-cell-middle plans-br plans-pad"><a href="#">London Heathrow Pickup</a>
                    </h4>

                    <p class="center plans-fs plans-price-fs ls distab-cell-middle plans-pad">£120 </p>
                </div>

                <!--=============== ROW-3 ==================-->
                <div class="distab plans-bg-2">
                    <h4 class="center plans-fs distab-cell-middle plans-br plans-pad"><a href="#">London Gatwick Drop-off</a>
                    </h4>

                    <p class="center plans-fs plans-price-fs ls distab-cell-middle plans-pad">£120 </p>
                </div>

                <!--=============== ROW-4 ==================-->
                <div class="distab plans-bg-1">
                    <h4 class="center plans-fs distab-cell-middle plans-br plans-pad"><a href="#">30 Minutes Waiting </a>
                    </h4>

                    <p class="center plans-fs plans-price-fs ls distab-cell-middle plans-pad">£10 </p>
                </div>

                <!--=============== ROW-5 ==================-->
                <div class="distab plans-bg-2 plans-radius-1">
                    <h4 class="center plans-fs distab-cell-middle plans-br plans-pad"><a href="#">All Meet & Greet </a>
                    </h4>

                    <p class="center plans-fs plans-price-fs ls distab-cell-middle plans-pad">£10 </p>
                </div>
            </div>

        </div>
    </div>
</section>
<!--================================= OUR BEST TARIFF PLANS END =============================================-->

<!--================================= OUR TEAM START =============================================-->
<!--
    <section class="container-fluid section-space section-bg-2">
        <div class="container">
            <h2 class="center h2-bottom">our team</h2>
            <div class="row">
                <!--==========  COLUMN-1 ===============-->
<!--
                <div class="col-md-3 col-sm-3 col-xs-6 common-res-bottom-1 common-full-1">
                    <div class="image-bottom">
                        <img src="images/400x500x1.png" alt="image" class="img-responsive image-center image-grow" />
                    </div>
                    <h4 class="center teambg-author-bottom">MARK MCGARVEY </h4>
                    <p class="center teambg-design ls">DIRECTOR </p>
                </div>

                <!--==========  COLUMN-2 ===============-->
<!--
                <div class="col-md-3 col-sm-3 col-xs-6 common-res-bottom-1 common-full-1">
                    <div class="image-bottom">
                        <img src="images/400x500x2.png" alt="image" class="img-responsive image-center image-grow" />
                    </div>
                    <h4 class="center teambg-author-bottom">MITCHELL CULWELL </h4>
                    <p class="center teambg-design ls">MANAGER </p>
                </div>

                <!--==========  COLUMN-3 ===============-->
<!--
                <div class="col-md-3 col-sm-3 col-xs-6 common-full-1 team-res-bottom">
                    <div class="image-bottom">
                        <img src="images/400x500x3.png" alt="image" class="img-responsive image-center image-grow" />
                    </div>
                    <h4 class="center teambg-author-bottom">NORBERTO KERBS </h4>
                    <p class="center teambg-design ls">MECHANIC </p>
                </div>

                <!--==========  COLUMN-4 ===============-->
<!--
               <div class="col-md-3 col-sm-3 col-xs-6 common-full-1">
                   <div class="image-bottom">
                       <img src="images/400x500x4.png" alt="image" class="img-responsive image-center image-grow" />
                   </div>
                   <h4 class="center teambg-author-bottom">DEWAYNE TAGGART</h4>
                   <p class="center teambg-design ls">DRIVER </p>
               </div>
           </div>
       </div>
   </section>
   <!--================================= OUR TEAM END =============================================-->

<!--================================= EMAIL SUBSCRIPTION START =============================================-->
<section class="container-fluid subscription-bgimage bgimage-property section-space white-text">
    <div class="container">
        <div class="col-md-10 column-center no-padding">
            <h2 class="center bgimage-head bgimage-head-bottom">email subscription</h2>
            <div class="col-md-8 column-center no-padding">
                <p class="center email-text-bottom ls">Subscribe in to our email notifications and get the chance to grab hottest offers</p>
            </div>
            <div id="mc_embed_signup">
                <div class="col-md-5 col-sm-6 col-xs-8 column-center no-padding">
                    <div class="form-top">
                        <!--================= YOUR MAILCHIMP ACCOUNT URL HERE ====================-->
                        <form class="subscribe_form" method="POST" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" action="http://evethemes.us11.list-manage.com/subscribe/post?u=a795532c55a578843e04b09c0&amp;id=fa362f029a" novalidate>
                            <!--================= EMAIL INPUT BOX HERE ====================-->
                            <div class="clearfix">
                                <input class="form-control place_error" id="mce-EMAIL" type="email" name="EMAIL" placeholder="Your Mail (required)" />
                            </div>

                            <!--================= SUBSCRIBE BUTTON HERE ====================-->
                            <div class="center btn-top">
                                <input type="submit" id="mc-embedded-subscribe" class="btn-1 btn-ant" name="submit" value="SUBSCRIBE">
                            </div>

                            <!--================= SUCCESS AND FAILURE MESSAGE HERE =================-->
                            <div class="center indicator-top" id="ResultMsg"><span id="SuccessMsg" class="email-success"></span><span id="FailureMsg" class="email-failure"></span>
                            </div>

                            <div id="mce-responses">
                                <div class="response response-msg" id="mce-error-response"></div>
                                <div class="response response-msg" id="mce-success-response"></div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================================= EMAIL SUBSCRIPTION END =============================================-->

<!--================================= OUR LATEST GALLERY START =============================================-->
<!--
    <section class="container-fluid section-space section-bg-2" id="gallery">
        <div class="container">
            <h2 class="center h2-bottom">our latest gallery</h2>
            <div class="row">
                <!--=============== COLUMN-1 ==================-->
<!--
                <div class="col-md-4 col-sm-4 gallery-pad gallery-res-bottom">
                    <div class="center">
                        <img src="images/500x713x1.jpg" alt="image" class="img-responsive image-center" />
                    </div>
                </div>

                <!--=============== COLUMN-2 ==================-->
<!--
                <div class="col-md-4 col-sm-4 gallery-pad gallery-res-bottom">
                    <div class="center gallery-row-bottom">
                        <img src="images/500x350x1.jpg" alt="image" class="img-responsive image-center" />
                    </div>

                    <div class="center">
                        <img src="images/500x350x2.jpg" alt="image" class="img-responsive image-center" />
                    </div>
                </div>

                <!--=============== COLUMN-3 ==================-->
<!--
               <div class="col-md-4 col-sm-4 gallery-pad gallery-res-bottom">
                   <div class="center">
                       <img src="images/500x713x2.jpg" alt="image" class="img-responsive image-center" />
                   </div>
               </div>


           </div>
       </div>
   </section>
   <!--================================= OUR LATEST GALLERY END =============================================-->

<!--================================= OUR LATEST NEWS START =============================================-->
<!--
    <section class="container-fluid section-space section-bg-1">
        <div class="container">
            <h2 class="center h2-bottom">our latest news</h2>
            <div class="row">
                <!--=============== COLUMN-1 ==================-->
<!--
                <div class="col-md-3 col-sm-6 col-xs-6 news-res-row-bottom common-res-bottom-1 common-full-1">
                    <div class="left image-bottom">
                        <img src="images/500x360x1.jpg" alt="image" class="img-responsive image-center" />
                    </div>
                    <h4 class="center h4-bottom"><a href="#">Donec varius</a></h4>
                    <p class="center">Donec varius sodales orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra</p>
                </div>

                <!--=============== COLUMN-2 ==================-->
<!--
                <div class="col-md-3 col-sm-6 col-xs-6 news-res-row-bottom common-res-bottom-1 common-full-1">
                    <div class="left image-bottom">
                        <img src="images/500x360x2.jpg" alt="image" class="img-responsive image-center" />
                    </div>
                    <h4 class="center h4-bottom"><a href="#">Donec varius</a></h4>
                    <p class="center">Donec varius sodales orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra</p>
                </div>

                <!--=============== COLUMN-3 ==================-->
<!--
                <div class="col-md-3 col-sm-6 col-xs-6 common-full-1 news-res-row-bottom-1">
                    <div class="left image-bottom">
                        <img src="images/500x360x3.jpg" alt="image" class="img-responsive image-center" />
                    </div>
                    <h4 class="center h4-bottom"><a href="#">Donec varius</a></h4>
                    <p class="center">Donec varius sodales orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra</p>
                </div>

                <!--=============== COLUMN-4 ==================-->
<!--
                <div class="col-md-3 col-sm-6 col-xs-6 common-full-1">
                    <div class="left image-bottom">
                        <img src="images/500x360x4.jpg" alt="image" class="img-responsive image-center" />
                    </div>
                    <h4 class="center h4-bottom"><a href="#">Donec varius</a></h4>
                    <p class="center">Donec varius sodales orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra</p>
                </div>
            </div>
        </div>
    </section>
    <!--================================= OUR LATEST NEWS END =============================================-->

<!--================================= OUR HAPPY CUSTOMERS START =============================================-->
<!--
    <section class="container-fluid section-space section-bg-2">
        <div class="container">
            <h2 class="center h2-bottom">our happy customers</h2>
            <div class="row">
                <!--=============== COLUMN-1 ==================-->
<!--
                <div class="col-md-4 col-sm-4 customers-fixed customers-res-bottom">
                    <div class="customer-bg">
                        <div class="center image-bottom">
                            <img src="images/100x100x1.png" alt="image" />
                        </div>
                        <p class="center customer-text ls">Donec varius sodales orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean a arcu ullamcorper</p>
                        <h4 class="center">MARK DAVID </h4>
                        <p class="center customer-design ls">Company </p>
                    </div>
                </div>

                <!--=============== COLUMN-2 ==================-->
<!--
                <div class="col-md-4 col-sm-4 customers-fixed customers-res-bottom">
                    <div class="customer-bg">
                        <div class="center image-bottom">
                            <img src="images/100x100x2.png" alt="image" />
                        </div>
                        <p class="center customer-text ls">Donec varius sodales orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean a arcu ullamcorper</p>
                        <h4 class="center">LARA EMILY</h4>
                        <p class="center customer-design ls">Company </p>
                    </div>
                </div>

                <!--=============== COLUMN-3 ==================-->
<!--
                <div class="col-md-4 col-sm-4 customers-fixed customers-res-bottom">
                    <div class="customer-bg">
                        <div class="center image-bottom">
                            <img src="images/100x100x3.png" alt="image" />
                        </div>
                        <p class="center customer-text ls">Donec varius sodales orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean a arcu ullamcorper</p>
                        <h4 class="center">DAVID JANET </h4>
                        <p class="center customer-design ls">Company </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--================================= OUR HAPPY CUSTOMERS END =============================================-->

<!--================================= HAPPY TRAVEL START =============================================-->
<!--
    <section class="container-fluid section-space section-bg-1">
        <div class="container">
            <div class="row">
                <div class="col-md-10 column-center no-padding res-width-full">
                    <div class="col-md-6 col-md-push-6 res-image-bottom res-image-bottom-1">
                        <div class="left">
                            <img src="images/750x400x1.jpg" alt="image" class="img-responsive image-center" />
                        </div>
                    </div>

                    <div class="col-md-6 col-md-pull-6">
                        <h3 class="left h3-bottom"><a href="#">happy travel</a></h3>
                        <p class="left p-bottom">Donec varius sodales orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean a arcu ullamcorper eros viverra suscipit. varius sodales. Donec varius sodales orci. Donec varius sodales orci</p>

                        <p class="left ">Donec varius sodales orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean a arcu ullamcorper eros viverra suscipit. varius sodales. Donec varius sodales orci. Donec varius sodales orci </p>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--================================= HAPPY TRAVEL END =============================================-->

<!--================================= SUPPORT START =============================================-->
<!--
   <div class="container-fluid support-bgimage bgimage-property support-section-space">
       <div class="container">
           <div class="col-md-10 column-center no-padding white-text">
               <h4 class="left support-text-bottom">24/7 SUPPORT AVAILABLE </h4>
               <div class="distab">
                   <div class="left distab-cell-middle">
                       <img src="images/64x64x9.png" alt="icon" />
                   </div>
                   <div class="left distab-cell-middle phone-left-pad">
                       <p class="left phone-text ls">+45 534 345 453</p>
                   </div>
               </div>
               <p class="left conditions-text ls">IMPORTANT TERMS &amp; CONDITIONS APPLY</p>
           </div>
       </div>

   </div>
   <!--================================= SUPPORT END =============================================-->

<!--================================= DOOR STEP SERVICE START =============================================-->
<!--
    <section class="container-fluid section-space section-bg-1">
        <div class="container">
            <div class="row">
                <div class="col-md-10 column-center no-padding res-width-full">
                    <div class="col-md-6 res-image-bottom res-image-bottom-1">
                        <div class="left">
                            <img src="images/750x400x2.jpg" alt="image" class="img-responsive image-center" />
                        </div>
                    </div>

                    <div class="col-md-6">
                        <h3 class="left h3-bottom"><a href="#">door step service</a></h3>
                        <p class="left p-bottom">Donec varius sodales orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean a arcu ullamcorper eros viverra suscipit. varius sodales. Donec varius sodales orci. Donec varius sodales orci</p>

                        <p class="left ">Donec varius sodales orci. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aenean a arcu ullamcorper eros viverra suscipit. varius sodales. Donec varius sodales orci. Donec varius sodales orci </p>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--================================= DOOR STEP SERVICE END =============================================-->

<!--================================= OUR HAPPY CUSTOMERS START =============================================-->
<!--
    <div class="container-fluid section-space section-bg-2">
        <div class="container">
            <div class="row">
                <div class="col-md-2 col-sm-4 col-xs-6">
                    <div class="left">
                        <img src="images/brands.png" alt="image" class="img-responsive image-center" />
                    </div>
                </div>

                <div class="col-md-2 col-sm-4 col-xs-6 res-client-space-1">
                    <div class="left">
                        <img src="images/brands.png" alt="image" class="img-responsive image-center" />
                    </div>
                </div>

                <div class="col-md-2 col-sm-4 col-xs-6 res-client-space">
                    <div class="left">
                        <img src="images/brands.png" alt="image" class="img-responsive image-center" />
                    </div>
                </div>

                <div class="col-md-2 col-sm-4 col-xs-6 res-client-space-1">
                    <div class="left">
                        <img src="images/brands.png" alt="image" class="img-responsive image-center" />
                    </div>
                </div>

                <div class="col-md-2 col-sm-4 col-xs-6">
                    <div class="left">
                        <img src="images/brands.png" alt="image" class="img-responsive image-center" />
                    </div>
                </div>

                <div class="col-md-2 col-sm-4 col-xs-6">
                    <div class="left">
                        <img src="images/brands.png" alt="image" class="img-responsive image-center" />
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!--================================= OUR HAPPY CUSTOMERS END =============================================-->

<!--================================= FOOTER START =============================================-->
<section class="container-fluid footer-section-space section-bg-1" id="contact">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-push-6 col-sm-6 col-xs-12 common-res-bottom-1">
                <h4 class="left contact-heading-bottom">contact</h4>

                <div class="contact-div">
                    <form id="contact-form" method="POST">
                        <div class="clearfix">
                            <!--================= NAME INPUT BOX HERE ====================-->
                            <div class="form-div form-bottom-1">
                                <input class="form-control form-text" id="name" type="text" name="name" value="" placeholder="Please Enter Name" required />
                            </div>

                            <!--================= EMAIL INPUT BOX HERE ====================-->
                            <div class="form-div form-bottom-1">
                                <input class="form-control form-text" id="email" type="email" name="email" value="" placeholder="Please Enter Email" required />
                            </div>

                            <!--================= MESSAGE INPUT BOX HERE ====================-->
                            <div class="form-div-1">
                                <textarea class="form-control form-text" id="message" name="message" placeholder="Message" rows="4" required></textarea>
                            </div>

                            <div class="distab submit-reset">
                                <!--================= SUBMIT BUTTON HERE ====================-->
                                <div class="distab-cell-middle submit-right-pad">
                                    <input type="submit" class="btn-1" id="submit" name="submit" value="SUBMIT">
                                </div>

                                <!--================= RESET BUTTON HERE ====================-->
                                <input type="reset" class="btn-1 distab-cell-middle cancel" name="clear" value="RESET">

                            </div>
                        </div>
                    </form>
                </div>
                <div class="right form-error-top" id="messageDiv"> <span class="form-success" id="sucessMessage"> </span> <span class="form-failure" id="failMessage"> </span>
                </div>
            </div>

            <div class="col-md-6 col-md-pull-6 col-sm-6 col-xs-12">
                <h4 class="center h4-bottom">address</h4>
                <p class="center ls adress-line-bottom">98 HOBART ROAD </p>
                <p class="center footer-row-space ls">CAMBRIDGE CB1 3PT </p>

                <h4 class="center h4-bottom">Email </h4>
                <p class="center footer-row-space ls"> <a href="#">info@taxiincambridge.co.uk</a>
                </p>

                <h4 class="center h4-bottom">phone no</h4>
                <p class="center footer-row-space ls"> +441223 247 247 </p>

                <h4 class="center follow-heading-bottom">follow us</h4>
                <div class="center">
                    <ul class="no-padding no-margin footer-icon footer-left-pad">
                        <li>
                            <a href="https://www.facebook.com/airportexpresspage/?ref=search&__tn__=%2Cd%2CP-R&eid=ARCjBTt3AFcLu3LLqL33ynNSXAkIoe7nh_JvpiYWDqwWJNvOcmV6H_z71fTap-awwQWmXeonyt6jZIzS">
                                <img src="images/32x32x4.png" alt="icon" />
                            </a>
                        </li>

                        <li>
                            <a href="https://g.co/kgs/bU3imK">
                                <img src="images/32x32x5.png" alt="icon" />
                            </a>
                        </li>

                        <li>
                            <a href="#">
                                <img src="images/32x32x6.png" alt="icon" />
                            </a>
                        </li>

                        <li>
                            <a href="#">
                                <img src="images/32x32x7.png" alt="icon" />
                            </a>
                        </li>

                        <li>
                            <a href="#">
                                <img src="images/32x32x8.png" alt="icon" />
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

        </div>
        <div class="footer-br footer-br-bottom"></div>
        <p class="center ls">&copy; 2019, All Rights Reserved, owned by Samif Ltd</p>
    </div>
</section>
<!--================================= FOOTER END =============================================-->

<!-- JQUERY LIBRARY -->
<script type="text/javascript" src="js/vendor/jquery.min.js"></script>
<!-- BOOTSTRAP -->
<script type="text/javascript" src="js/vendor/bootstrap.min.js"></script>

<!-- SUBSCRIBE MAILCHIMP -->
<script type="text/javascript" src="js/vendor/subscribe/subscribe_validate.js"></script>

<!-- VALIDATION  -->
<script type="text/javascript" src="js/vendor/validate/jquery.validate.min.js"></script>

<!-- COUNTER JS FILES -->
<script type="text/javascript" src="js/vendor/counter/counter-lib.js"></script>
<script type="text/javascript" src="js/vendor/counter/jquery.counterup.min.js"></script>

<!-- SLIDER JS FILES -->
<script type="text/javascript" src="js/vendor/slider/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/vendor/slider/carousel.js"></script>

<!-- SUBSCRIBE MAILCHIMP -->
<script type="text/javascript" src="js/vendor/subscribe/subscribe_validate.js"></script>

<!-- VIDEO -->
<script type="text/javascript" src="js/vendor/video/video.js"></script>


<!-- THEME JS -->
<script type="text/javascript" src="js/custom/custom.js"></script>

</body>

</html>