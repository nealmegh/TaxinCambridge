<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/Frontend/Associate/features.blade.php */ ?>
<!--================ Feature section start =================-->
<section class="about-sect">
    <div class="container">
        <div class="row no-gutters align-items-center">
            <div class="col-md-7 mb-7 mb-md-0">
                <div class="about-text-sect">
                    <h3> <img class="heading-images" src="<?php echo e(asset("images/home/untitled-2.png")); ?>">Most Reliable Cambridge taxi for Airport Transfer</h3>
                    <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                </div>
            </div>

            <div class="col-md-5 mb-5 mb-md-0">
                <div class="offers">
                    <h2>Why book with us?</h2>
                    <div class="offer"><h3><span class="offer-num"><b>1</b></span>FREE Waiting Time Upto one hour</h3></div>
                    <div class="offer"><h3><span class="offer-num"><b>1</b></span>FREE Waiting Time Upto one hour</h3></div>
                    <div class="offer"><h3><span class="offer-num"><b>1</b></span>FREE Waiting Time Upto one hour</h3></div>
                    <div class="offer"><h3><span class="offer-num"><b>1</b></span>FREE Waiting Time Upto one hour</h3></div>
                    <div class="offer"><h3><span class="offer-num"><b>1</b></span>FREE Waiting Time Upto one hour</h3></div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================ Feature section end =================-->

<!--================ About section start =================-->
<section class="about-sect-2">
    <div class="container">
        <div class="row no-gutters align-items-center">
            <h3> <img class="heading-images" src="<?php echo e(asset("images/home/untitled-1.png")); ?>">Your best & comfy airport transfer taxi in CAMBRIDGE for competitive price.</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
    </div>
</section>
<!--================ About section end =================-->