<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/Backend/User/Role/Associate/js.blade.php */ ?>
<script src="<?php echo e(asset("js/jquery.dataTables.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/dataTables.bootstrap.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/dataTables.buttons.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/buttons.bootstrap.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/buttons.flash.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/buttons.html5.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/buttons.print.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/dataTables.fixedHeader.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/dataTables.keyTable.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/dataTables.responsive.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/responsive.bootstrap.js")); ?>"></script>
<script src="<?php echo e(asset("js/dataTables.scroller.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/szip.min.js")); ?>j"></script>
<script src="<?php echo e(asset("js/pdfmake.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/vfs_fonts.js")); ?>"></script>
<script src="<?php echo e(asset("js/validator.js")); ?>"></script>


