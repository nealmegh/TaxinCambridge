<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/2Frontend/Booking/confirmation.blade.php */ ?>
<?php $__env->startSection('content'); ?>
    <div ></div>
    <section id="confirm" class="booking-form" >
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="container confirm">
            <div class="row confirm">
                <div class="col-md-12 col-sm-12">

                    <h3>Your Booking ID: <?php echo e($booking->id); ?></h3>
                    <h3>Your Booking amount: £<?php echo e($booking->final_price); ?></h3>
                    <div class="col-md-12 col-sm-12" style="float: right">
                        
                        <?php if($siteSettings[8]->value != "0" ): ?>
                        <form class="form-horizontal " novalidate method="POST" action="<?php echo e(route('cashPayment')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($booking->id); ?>">
                            <button style="margin-top: 1px" name="type" value="cash" id="bookingButton" class="btn confirmBtn" type="submit"> <?php echo e('Pay Cash'); ?> </button>
                        </form>
                        <?php endif; ?>
                        <form class="form-horizontal form-label-left" novalidate method="POST" action="<?php echo e(route('paypalPayment')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="amount" value="<?php echo e($booking->final_price); ?>">
                            <input type="hidden" name="booking_id" value="<?php echo e($booking->id); ?>">
                            <button style="margin-top: 1px" name="type" value="paypal" id="bookingButton2" class="btn confirmBtn" type="submit"><?php echo e('Pay By Paypal'); ?></button>
                        </form>
                    </div>

                </div></div></div></section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $( document ).ready(function() {
        console.log( "ready!" );
        $('html, body').animate({
            scrollTop: $("#confirm").offset().top
        }, 2000);
    });
</script>
<?php $__env->appendSection(); ?>
<?php echo $__env->make('2Frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>