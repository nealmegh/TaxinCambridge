<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/Frontend/layout.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('Frontend.Associate.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
<!--================Header Menu Area =================-->
<?php echo $__env->make('Frontend.Associate.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--================Header Menu Area =================-->


<main class="side-main">
   <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('Frontend.Associate.features', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</main>


<!-- ================ Start footer Area ================= -->
<?php echo $__env->make('Frontend.Associate.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ================ End footer Area ================= -->







<script src="<?php echo e(asset("js/Frontend/jquery/jquery-3.2.1.min.js")); ?>" ></script>
<script src="<?php echo e(asset("js/Frontend/bootstrap/bootstrap.bundle.min.js")); ?>" ></script>
<script src="<?php echo e(asset("js/Frontend/owl-carousel/owl.carousel.min.js")); ?>" ></script>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>



<?php echo $__env->yieldContent('js'); ?>
</body>
</html>