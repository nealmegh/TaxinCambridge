<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/Backend/Booking/index.blade.php */ ?>
<?php $__env->startSection('css'); ?>
    <?php echo $__env->make('Backend.Car.Associate.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="page-title">


            <div class="title_right">

                
                    
                
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Basic Model <small>Bookings</small></h2>
                        <ul class="nav navbar-right panel_toolbox">

                            <li><a title="Create a Booking" href="<?php echo e(route('booking.create')); ?>" class="btn btn-app">
                                    <i class="fa fa-user"></i> <span>Create </span>
                                </a>
                                
                            </li>
                        </ul>

                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        
                            
                        
                        <table id="datatable1" class="table table-striped table-bordered">
                            <thead>
                            <tr>
                                <th>Booking ID</th>
                                <th>Customer Name</th>
                                <th>Email</th>
                                <th>Phone Number</th>
                                <th>Price</th>
                                <th>Driver</th>
                                <th>Payment</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                            </thead>


                            <tbody>
                            <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($booking->id); ?></td>
                                <?php if($booking->user != null): ?>
                                <td><?php echo e($booking->user->name); ?></td>
                                <td><?php echo e($booking->user->email); ?></td>
                                <td><?php echo e($booking->user->phone); ?></td>
                                <?php else: ?>
                                    <td><?php echo e('Customer Data is Not Available'); ?></td>
                                    <td><?php echo e('Customer Data is Not Available'); ?></td>
                                    <td><?php echo e('Customer Data is Not Available'); ?></td>
                                <?php endif; ?>
                                <?php if($booking->final_price == null): ?>
                                    <td><?php echo e($booking->price); ?></td>
                                <?php else: ?>
                                    <td><?php echo e($booking->final_price); ?></td>
                                <?php endif; ?>

                                <?php if($booking->driver == null): ?>
                                    <td>
                                        <a href="<?php echo e(route('booking.assign', $booking->id)); ?>" data-toggle="modal" class="btn btn-sm btn-info editFunction" data-row-id="37">
                                        Assign</a>
                                    </td>
                                <?php else: ?>
                                <td><?php echo e($booking->driver->name); ?></td>
                                <?php endif; ?>
                                <?php if($booking->user_transaction_id == null): ?>
                                    <td>
                                        <a href="<?php echo e(route('booking.payment', $booking->id)); ?>" data-toggle="modal" class="btn btn-sm btn-info editFunction" data-row-id="37">
                                            Payment Confirmation</a>
                                    </td>
                                <?php else: ?>
                                    <td><?php echo e($booking->userTransaction->payment_id); ?></td>
                                <?php endif; ?>

                                    <?php if($booking->complete_status == Null): ?>
                                    <td> <a href="<?php echo e(route('booking.complete', $booking->id)); ?>" data-toggle="modal" class="btn btn-sm btn-info editFunction" data-row-id="37">
                                            Job Completion</a> </td>
                                    <?php else: ?>
                                    <td><?php echo e('Completed'); ?></td>
                                    <?php endif; ?>

                                <td>
                                    
                                        
                                    
                                    <a  href="<?php echo e(route('booking.edit', $booking->id)); ?>" data-toggle="modal" class="btn btn-sm btn-warning editFunction" data-row-id="37">
                                        <i class="fa fa-pencil"></i>
                                    </a>
                                    ||

                                    <a class="btn btn-danger" onclick="return confirm('Are you sure?')" href="<?php echo e(route('booking.delete', $booking->id)); ?>" class="btn btn-sm btn-danger">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('Backend.Car.Associate.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <script>
        $(document).ready(function() {
            $('#datatable1').DataTable( {
                "aaSorting": [[ 0, "desc" ]]
            } );
        } );
    </script>
<?php $__env->appendSection(); ?>
<?php echo $__env->make('Backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>