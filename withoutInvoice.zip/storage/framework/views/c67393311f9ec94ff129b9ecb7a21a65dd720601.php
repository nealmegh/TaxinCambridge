<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/Frontend/Associate/head.blade.php */ ?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title>Taxi in Cambridge - Home</title>

<link rel="icon" href="<?php echo e(asset("images/taxi.png")); ?>" type="image/png">
<!-- Bootstrap -->
<link href="<?php echo e(asset("css/bootstrap.min.css")); ?>" rel="stylesheet">
<!-- Font Awesome -->
<link href="<?php echo e(asset("css/font-awesome.min.css")); ?>" rel="stylesheet">




<link href="<?php echo e(asset("css/Frontend/linericon/style.css")); ?>" rel="stylesheet">
<link href="<?php echo e(asset("css/Frontend/themify-icons/themify-icons.css")); ?>" rel="stylesheet">
<link href="<?php echo e(asset("css/Frontend/owl-carousel/owl.theme.default.min.css")); ?>" rel="stylesheet">
<link href="<?php echo e(asset("css/Frontend/owl-carousel/owl.carousel.min.css")); ?>" rel="stylesheet">



<link href="<?php echo e(asset("css/Frontend/style.css")); ?>" rel="stylesheet">