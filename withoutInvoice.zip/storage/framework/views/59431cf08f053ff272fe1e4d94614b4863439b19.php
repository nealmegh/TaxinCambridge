<?php /* D:\Current Projects\Biswjit\Codebase\resources\views/Backend/Booking/edit.blade.php */ ?>
<?php $__env->startSection('css'); ?>
    
<?php $__env->appendSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>User <small>Edit</small></h2>

                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form class="form-horizontal form-label-left" novalidate method="post" action="<?php echo e(route('booking.update', $booking->id )); ?>">

                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="selectFrom" class="control-label col-md-3 col-sm-3 col-xs-12">From</label>
                                        <div class="col-md-9 col-sm-9 col-xs-12">
                                            <select id="selectFrom" name="selectFrom" class="select2_group form-control">
                                                <option value="placeholder" selected>Choose a Pick-Up Point</option>
                                                <optgroup label="Airports">

                                                    <?php $__currentLoopData = $airports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($booking->from_to != 'loc' && $booking->airport->id == $airport->id): ?>
                                                            <option value="<?php echo e('air'.$airport->id); ?>" selected><?php echo e($airport->display_name); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e('air'.$airport->id); ?>"><?php echo e($airport->display_name); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </optgroup>
                                                <optgroup label="Area">
                                                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($booking->from_to == 'loc' && $booking->location->id == $location->id): ?>
                                                            <option value="<?php echo e('loc'.$location->id); ?>" selected><?php echo e($location->display_name); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e('loc'.$location->id); ?>"><?php echo e($location->display_name); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </optgroup>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="selectTo" class="control-label col-md-3 col-sm-3 col-xs-12">To</label>
                                        <div class="col-md-9 col-sm-9 col-xs-12">
                                            <select id="selectTo" name="selectTo" class="select2_group form-control">
                                                <?php if($booking->from_to == 'loc'): ?>
                                                    

                                                        <?php $__currentLoopData = $airports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if( $booking->airport->id == $airport->id): ?>
                                                                <option value="<?php echo e($airport->id); ?>" selected><?php echo e($airport->display_name); ?></option>
                                                            <?php else: ?>
                                                                <option value="<?php echo e($airport->id); ?>"><?php echo e($airport->display_name); ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                <?php else: ?>
                                                    
                                                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($booking->location->id == $location->id): ?>
                                                                <option value="<?php echo e($location->id); ?>" selected><?php echo e($location->display_name); ?></option>
                                                            <?php else: ?>
                                                                <option value="<?php echo e($location->id); ?>"><?php echo e($location->display_name); ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="pickup_address">Pick Up Address <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="pickup_address" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" data-validate-words="2" name="pickup_address" value="<?php echo e($booking->pickup_address); ?>" placeholder="Put Pickup Address" required="required" type="text">
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="dropoff_address">Drop Off Address <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="dropoff_address" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" data-validate-words="2" name="dropoff_address" value="<?php echo e($booking->dropoff_address); ?>" placeholder="Put Drop Off Address" required="required" type="text">
                                </div>
                            </div>
                            
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="journey_date">Journey Date <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="journey_date" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" data-validate-words="2" name="journey_date" value="<?php echo e(date('Y-m-d',strtotime($booking->journey_date))); ?>" placeholder="Journey Date" required="required" type="date">

                                    
                                    
                                    
                                    
                                    

                                    


                                </div>
                            </div>

                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="pickup_time">Journey Time <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    


                                    
                                    <div class='input-group date' id='pickup_time'>
                                        <input type='text' class="form-control" name="pickup_time" value="<?php echo e($booking->pickup_time); ?>" />
                                        <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                    </div>
                                    

                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="flight_number">Flight/Train Number <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="flight_number" class="form-control col-md-7 col-xs-12" name="flight_number" value="<?php echo e($booking->flight_number); ?>" placeholder="Flight/Train Name" required="required" type="text">
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="flight_origin">Flight Name <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="flight_origin" class="form-control col-md-7 col-xs-12" name="flight_origin" value="<?php echo e($booking->flight_origin); ?>" placeholder="Flight/Train Number" required="required" type="text">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="return" class="control-label col-md-3 col-sm-3 col-xs-12">Return Journey</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select id="return" name="return" class="form-control">
                                        <?php if($booking->return == 0): ?>
                                            <option value=0 selected>No</option>
                                            <option value=1>Yes</option>
                                        <?php else: ?>
                                            <option value=0 >No</option>
                                            <option value=1 selected>Yes</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="return_date">Return Journey Date <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="return_date" class="form-control col-md-7 col-xs-12" name="return_date" value="<?php echo e(date('Y-m-d',strtotime($booking->return_date))); ?>" placeholder="Return Journey Date" required="required" type="date">
                                    
                                    
                                    
                                    
                                    
                                    
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="return_time">Return Time <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    


                                    
                                    <div class='input-group date' id='return_time'>
                                        <input type='text' class="form-control" name="return_time" value="<?php echo e($booking->return_time); ?>" />
                                        <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                    </div>
                                    

                                </div>
                            </div>
                            <div class="item form-group" id="rFlight" style="">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="return_flight_number">Flight/Train Number <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="return_flight_number" class="form-control col-md-7 col-xs-12" name="return_flight_number" placeholder="Flight/Train Name" required="required" type="text" value="<?php echo e($booking->return_flight_number); ?>">
                                </div>
                            </div>
                            <div class="item form-group" id="rOrigin" style="">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="return_flight_origin">Flight Origin<span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="return_flight_origin" class="form-control col-md-7 col-xs-12" name="return_flight_origin" placeholder="Flight/Train Number" required="required" type="text" value="<?php echo e($booking->return_flight_origin); ?>">
                                </div>
                            </div>

                            <div class="item form-group">
                                <label for="car_type" class="control-label col-md-3 col-sm-3 col-xs-12">Car Type</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select id="car_type" class="form-control" name="car_id">
                                        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($booking->car->id == $car->id): ?>
                                                <option value="<?php echo e($car->id); ?>" selected><?php echo e($car->name.' '.$car->description); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($car->id); ?>"><?php echo e($car->name.' '.$car->description); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label for="user_id" class="control-label col-md-3 col-sm-3 col-xs-12">Customer</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select id="user_id" class="form-control" name="user_id">
                                        <option>Chooose One</option>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($booking->user->id == $user->id): ?>
                                                <option value="<?php echo e($user->id); ?>" selected><?php echo e($user->name); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($user->id); ?>" ><?php echo e($user->name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="meet" class="control-label col-md-3 col-sm-3 col-xs-12">Meet & Greet (£10)</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select id="meet" name="meet" class="form-control">
                                        <?php if($booking->meet == 0): ?>
                                            <option value=0 selected>No</option>
                                            <option value=1>Yes</option>
                                        <?php else: ?>
                                            <option value=0 >No</option>
                                            <option value=1 selected>Yes</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="adult" class="control-label col-md-3 col-sm-3 col-xs-12">Adult & Child</label>
                                <div class="col-md-3 col-sm-3 col-xs-12 ">
                                    <input type="number" class="form-control has-feedback-left" id="adult" name="adult" value="<?php echo e($booking->adult); ?>" placeholder="Adult">

                                    
                                </div>
                                <div class="col-md-3 col-sm-3 col-xs-12 ">
                                    <input type="number" class="form-control has-feedback-left" id="child" name="child" value="<?php echo e($booking->child); ?>" placeholder="Child">

                                    
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="luggage" class="control-label col-md-3 col-sm-3 col-xs-12">Luggage & Carry On</label>
                                <div class="col-md-3 col-sm-3 col-xs-12 ">
                                    <input type="number" class="form-control has-feedback-left" id="luggage" name="luggage" value="<?php echo e($booking->luggage); ?>" placeholder="Luggage">

                                    
                                </div>
                                <div class="col-md-3 col-sm-3 col-xs-12 ">
                                    <input type="number" class="form-control has-feedback-left" id="carryon" name="carryon" value="<?php echo e($booking->carryon); ?>" placeholder="Carry On">

                                    
                                </div>
                            </div>
                            <div class="item form-group">
                                <label for="add_info" class="control-label col-md-3 col-sm-3 col-xs-12">Additional Info <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    
                                    <textarea id="booking_details" class="form-control col-md-7 col-xs-12" name="add_info" placeholder="Type Here"><?php echo e($booking->add_info); ?></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="discount_type" class="control-label col-md-3 col-sm-3 col-xs-12">Discount Type</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select class="form-control" id="discount_type" name="discount_type" >
                                        <?php if($booking->discount_type == 0): ?>
                                            <option value=0 selected>Fixed</option>
                                            <option value=1>Percentage</option>
                                        <?php else: ?>
                                            <option value=0 selected>Fixed</option>
                                            <option value=1 selected>Percentage</option>
                                        <?php endif; ?>
                                    </select>

                                </div>
                            </div>
                            <div class="form-group">
                                <label for="discount_value" class="control-label col-md-3 col-sm-3 col-xs-12">Discount Value</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="number" class="form-control" id="discount_value" name="discount_value" value="<?php echo e($booking->discount_value); ?>" placeholder="Discount Value">
                                </div>
                            </div>

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            


                            <div class="ln_solid"></div>
                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-3">
                                    <button type="submit" class="btn btn-primary">Cancel</button>
                                    <button id="send" type="submit" class="btn btn-success">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('Backend.Car.Associate.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <script type="text/javascript">

        $('#selectFrom').on('change', function() {
            var e = document.getElementById("selectFrom");
            var selectValue = e.options[e.selectedIndex].value;
            var air = 'air';
            var check = selectValue.search(air);
            $("#hiddenFrom").val(function() {
                return selectValue;
            });
            if(check == 0)
            {
                // var select = document.getElementById("selectTo").empty();
                var select =

                    $('#selectTo')
                        .find('option')
                        .remove()
                        .end()
                        .append('<option value="">Choose a Drop-Off Point</option>')
                ;


                var locations = <?php echo json_encode($locations); ?>;
                // console.log(airports[0].name);
                for(var i=0; i<locations.length; i++)
                {
                    var option = document.createElement("option");
                    option.text = locations[i].display_name;
                    option.value = locations[i].id;
                    var select = document.getElementById("selectTo");
                    select.appendChild(option);

                }

            }
            else {
                var select =

                    $('#selectTo')
                        .find('option')
                        .remove()
                        .end()
                        .append('<option value="">Choose a Drop-Off Point</option>')
                ;
                var airports = <?php echo json_encode($airports); ?>;
                // console.log(airports[0].name);
                for(var i=0; i<airports.length; i++)
                {
                    var option = document.createElement("option");
                    option.text = airports[i].display_name;
                    option.value = airports[i].id;
                    var select = document.getElementById("selectTo");
                    select.appendChild(option);

                }
            }
        });
        // var dateToday = new Date();
        // $('#journey_date').datetimepicker({
        //     useCurrent: false,
        //     minDate: dateToday,
        //     format: 'DD.MM.YYYY',
        // });
        //
        // $('#return_date').datetimepicker({
        //     useCurrent: false,
        //     format: 'DD.MM.YYYY',
        // });
        //
        //
        // $("#journey_date").on("dp.change", function(e) {
        //     $('#return_date').data("DateTimePicker").minDate(e.date);
        // });
        //
        // $("#return_date").on("dp.change", function(e) {
        //     $('#journey_date').data("DateTimePicker").maxDate(e.date);
        // });
        $('#pickup_time').datetimepicker({
            format: 'hh:mm A'
        });
        $('#return_time').datetimepicker({
            format: 'hh:mm A'
        });

    </script>
<?php $__env->appendSection(); ?>
<?php echo $__env->make('Backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>