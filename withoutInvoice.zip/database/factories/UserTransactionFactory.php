<?php

use Faker\Generator as Faker;

$factory->define(App\UserTransaction::class, function (Faker $faker) {
    return [
        //
    ];
});
