{{$data['from']}}
{{$data['message']}}

