{{--Datatables CSS--}}
<link href=" {{asset("css/bootstrap-progressbar-3.3.4.min.css")}} " rel="stylesheet">

<link href="{{asset("css/dataTables.bootstrap.min.css")}}" rel="stylesheet">
<link href="{{asset("css/buttons.bootstrap.min.css")}}" rel="stylesheet">
<link href="{{asset("css/fixedHeader.bootstrap.min.css")}}" rel="stylesheet">
<link href="{{asset("css/responsive.bootstrap.min.css")}}" rel="stylesheet">
<link href="{{asset("css/scroller.bootstrap.min.css")}}" rel="stylesheet">