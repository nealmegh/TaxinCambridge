<script src="{{asset("js/jquery.dataTables.min.js")}}"></script>
<script src="{{asset("js/dataTables.bootstrap.min.js")}}"></script>
<script src="{{asset("js/dataTables.buttons.min.js")}}"></script>
<script src="{{asset("js/buttons.bootstrap.min.js")}}"></script>
<script src="{{asset("js/buttons.flash.min.js")}}"></script>
<script src="{{asset("js/buttons.html5.min.js")}}"></script>
<script src="{{asset("js/buttons.print.min.js")}}"></script>
<script src="{{asset("js/dataTables.fixedHeader.min.js")}}"></script>
<script src="{{asset("js/dataTables.keyTable.min.js")}}"></script>
<script src="{{asset("js/dataTables.responsive.min.js")}}"></script>
<script src="{{asset("js/responsive.bootstrap.js")}}"></script>
<script src="{{asset("js/dataTables.scroller.min.js")}}"></script>
<script src="{{asset("js/szip.min.js")}}j"></script>
<script src="{{asset("js/pdfmake.min.js")}}"></script>
<script src="{{asset("js/vfs_fonts.js")}}"></script>
<script src="{{asset("js/validator.js")}}"></script>


