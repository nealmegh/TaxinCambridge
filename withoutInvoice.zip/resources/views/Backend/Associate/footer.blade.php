<footer>
    <div class="pull-right">
        Taxi in Cambridge made by <a href="https://bluwebz.com">Bluwebz</a>
    </div>
    <div class="clearfix"></div>
</footer>