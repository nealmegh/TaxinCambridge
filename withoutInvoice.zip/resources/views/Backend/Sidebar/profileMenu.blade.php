
<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
    <div class="menu_section">
        <h3>General</h3>
        <ul class="nav side-menu">
            <li><a href="{{route('userProfile')}}"><i class="fa fa-calendar"></i> Bookings <span class="fa fa-chevron-down"></span></a>

            </li>
            <li><a href="{{route('about')}}"><i class="fa fa-user"></i> My Info's <span class="fa fa-chevron-down"></span></a>
            </li>

        </ul>
    </div>
</div>
