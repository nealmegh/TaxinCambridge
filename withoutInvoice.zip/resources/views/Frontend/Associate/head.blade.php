<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>Taxi in Cambridge - Home</title>
{{--<link rel="icon" href="img/taxi.png" type="image/png">--}}
<link rel="icon" href="{{asset("images/taxi.png")}}" type="image/png">
<!-- Bootstrap -->
<link href="{{asset("css/bootstrap.min.css")}}" rel="stylesheet">
<!-- Font Awesome -->
<link href="{{asset("css/font-awesome.min.css")}}" rel="stylesheet">

{{--<link rel="stylesheet" href="vendors/fontawesome/css/all.min.css">--}}
{{--<link rel="stylesheet" href="vendors/themify-icons/themify-icons.css">--}}
{{--<link rel="stylesheet" href="vendors/linericon/style.css">--}}
<link href="{{asset("css/Frontend/linericon/style.css")}}" rel="stylesheet">
<link href="{{asset("css/Frontend/themify-icons/themify-icons.css")}}" rel="stylesheet">
<link href="{{asset("css/Frontend/owl-carousel/owl.theme.default.min.css")}}" rel="stylesheet">
<link href="{{asset("css/Frontend/owl-carousel/owl.carousel.min.css")}}" rel="stylesheet">


{{--<link rel="stylesheet" href="css/style.css">--}}
<link href="{{asset("css/Frontend/style.css")}}" rel="stylesheet">